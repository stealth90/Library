package com.company;

public class Quadrupede extends TerrestrialAnimal {
    public Quadrupede(String s){super(s);}
    public String move(){return "walking on 4 legs";}
    public String whoAre(){return "an animal with 4 legs";}
}
