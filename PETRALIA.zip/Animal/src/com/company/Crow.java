package com.company;

public class Crow extends Bird {
    public Crow(String s){super(s); bark="croaks";}
    public String whoAre(){return "a crow";}
}
