package com.company;

public class Horse extends Quadrupede {
    public Horse(String s){super(s); bark="neighing";}
    public String whoAre(){return "a horse";}
}
