package com.company;

public class Penguin extends Bipede {
    public Penguin(String s){super(s); bark="don't bark";}
    public String whoAre(){return "a penguin"; }
    public String move(){return "don't know how flying";}
}
