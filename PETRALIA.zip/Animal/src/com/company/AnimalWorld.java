package com.company;

public class AnimalWorld {

    public static void main(String[] args) {
	Horse a = new Horse("Furia");
	Human b = new Human("Matteo");
	Crow c = new Crow("Pippo");
	Tuna d = new Tuna("Filippo");
	Bird e = new Bird("Titti");
	Penguin f = new Penguin("Hippo");
	a.show();
	b.show();
	c.show();
	d.show();
	e.show();
	f.show();
    }
}
