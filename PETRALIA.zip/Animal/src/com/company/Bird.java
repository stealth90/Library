package com.company;

public class Bird extends TerrestrialAnimal {
    public Bird(String s){super(s); bark="twitter";}
    public String move(){return "flying";}
    public String whoAre(){return "a bird";}
    public String live(){return "in a neston a tree";}

}
