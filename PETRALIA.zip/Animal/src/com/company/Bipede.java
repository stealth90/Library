package com.company;

public class Bipede extends TerrestrialAnimal {
    public Bipede(String s){super(s);}
    public String move(){return "walk on 2 legs";}
    public String whoAre(){return "an animal with two legs";}
}
