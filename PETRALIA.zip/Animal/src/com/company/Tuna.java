package com.company;

public class Tuna extends Fish {
    public Tuna(String s){super(s); }
    public String whoAre(){return "a tuna";}
}
