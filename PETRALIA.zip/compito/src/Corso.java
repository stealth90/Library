public class Corso {
    int progressivo;
    int annInizio;
    String citta;
    int durata;
    Materia[] materie;

}
