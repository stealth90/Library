import java.util.Date;

public class RigaLibretto extends Materia{
    Date data;
    int voto;
}
