import java.util.Date;

public class Persona {
    String nome;
    String cognome;
    Date nascita;
}
