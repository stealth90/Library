public class Istituto {
}
