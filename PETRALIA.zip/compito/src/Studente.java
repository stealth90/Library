public class Studente extends Persona{
    RigaLibretto[] libretto;
}
