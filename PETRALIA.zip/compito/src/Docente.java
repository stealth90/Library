public class Docente extends Persona{
    String[] titoli;
}
