public class Segreteria {
    Impiegato[] impiegati;
}
