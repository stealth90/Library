public class Impiegato extends Persona{
}
