public class Materia {
    String nome;
    String code;
    int ore;
    Docente docente;
}
